<?php require_once 'common/header.php'; ?>
<?php
$listSliderFile = showSliderInSite();
if (!empty($listSliderFile)) {
    ?>
    <div id="carousel" class="carousel" style="  opacity: 1!important;
  -webkit-transition: opacity .15s linear!important;
  transition: opacity .15s linear!important;" data-ride="carousel">
        <!--slider-indicators-->
        <ol class="carousel-indicators">
            <li data-target="#carousel" data-slide-to="0" class="active"></li>
            <?php
            for ($i = 1; $i < count($listSliderFile); $i++) {
                ?>
                <li data-target="#carousel" data-slide-to="<?php echo $i; ?>"></li>
            <?php } ?>
        </ol>
        <!--image wrapper-->
        <div class="carousel-inner" id="custom-carousel-inner">
            <div class="item active">
                <img src="admin/img/slider/<?php echo $listSliderFile['0']['slidename']; ?>" class="img_Slider"
                     alt="image">
            </div>

            <?php
            for ($i = 1; $i < count($listSliderFile); $i++) {
                ?>
                <div class="item">
                    <img src="admin/img/slider/<?php echo $listSliderFile[$i]['slidename']; ?>" class="img_Slider"
                         alt="image">
                </div>
            <?php } ?>
        </div>
    </div>
<?php } ?>
</div>


<div class="container m18top">
    <div class="box_title">
        <div class="col-sm-6">
            <p class="view" style="">مشاهده ی همه ی متن های سایت</p>
        </div>
        <div class="col-sm-6">
            <form class="navbar-form navbar-left" method="get" action="search.php">
                <div class="input-group">
                    <input name="search" type="text" class="form-control" placeholder="نام پست را جهت جستجو وارد نمایید">
                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit">
                            جستجو
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="box_post">
        <?php
        $showPostForShowInSite = showPostForShowInSite();
        if(!empty($showPostForShowInSite)){

        foreach ($showPostForShowInSite as $value) {
            ?>
            <div class="col-xs-12 col-sm-4 boxPost">
                <div class="panel panel-default">
                    <div class="panel-heading panel_heading_custome">
                        <img src="<?php echo 'admin/img/post/' . $value['pic']; ?>" class="img-responsive"/>
                        <span class="i_date"><?php echo convertToShamsi($value['time']); ?></span>
                    </div>
                    <div class="panel-body panel_body_custome">
                        <p><?php echo $value['title']; ?></p>
                        <br/>
                        <a href="page.php?<?php echo 'id='.$value['id']; ?>"
                           class="btn btn-success pull-left btn_custome buttontwo">ادامه مطلب ...</a>
                    </div>
                </div>
            </div>
        <?php
        }}
        else{
            echo '<div class="alert alert-warning">پستی در سایت جهت نمایش وجود ندارد</div>';
        }
        ?>

    </div>

</div>


<div class="container">
    <center>
        <ul class="pagination">
            <li><a href="#" class="paginationColor">1</a></li>
            <li class="active paginationColor"><a href="#">2</a></li>
            <li><a href="#" class="paginationColor">3</a></li>
            <li><a href="#" class="paginationColor">4</a></li>
            <li><a href="#" class="paginationColor">5</a></li>
        </ul>
    </center>
</div>


<?php require_once 'common/footer.php' ?>


