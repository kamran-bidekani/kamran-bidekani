<?php
include_once '../models/loginCode.php';
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $result = $database->prepare('DELETE FROM members WHERE id=?');
    $result->bindValue(1, $_GET['id']);
    $result->execute();
    if ($result->rowCount() >= 1) {
        header('location:../dashbord.php?listmember=ok');
    } else {
        header('location:listMember.php');

    }
} else {
    header('location:../dashbord.php');
}

?>