<?php
$list = listCategory();
?>
<div class="container" style="margin-top: 10px;">
    <div class="col-sm-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                لیست دسته بندی های سایت
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr class="success">
                            <th class="text-center">ایدی</th>
                            <th class="text-center"> نام دسته بندی به فارسی</th>
                            <th class="text-center">نام دسته بندی به لاتین</th>
                            <th class="text-center">حذف دسته بندی</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if (!empty($list)) {
                            foreach ($list as $value) {
                                ?>
                                <tr>
                                    <td class="text-center"><?php echo $value['id']; ?></td>
                                    <td class="text-center"> <?php echo $value['name']; ?></td>
                                    <td class="text-center"><?php echo $value['slug'] ?></td>
                                    <td class="text-center"><a
                                                href="<?php echo 'dashbord.php?deleteCategory=' . $value['id'] ?>">حذف</a></td>
                                </tr>
                            <?php }
                        } else {
                            echo '<div class="alert alert-danger" style="margin: 5px;">';
                            echo 'دسته بندی وجود ندارد';
                            echo '</div>';
                        } ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
