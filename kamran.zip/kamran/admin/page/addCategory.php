<?php
addCategory();
?>
<form method="post" style="margin-top: 20px;">
    <div class="col-sm-8 col-sm-offset-2" style="background-color: #fff!important;padding: 10px;">
        <p>افزودن دسته بندی</p>
        <div class="form-group">
            <input type="text" class="form-control" name="addcategoryF" placeholder="نام دسته بندی به فارسی">
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="addcategoryE" placeholder="نام دسته بندی به لاتین">
        </div>
        <button class="btn btn-primary btn-block" name="btnaddCategory">افزودن</button>
    </div>
</form>