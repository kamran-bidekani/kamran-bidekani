<?php
if (isset($_GET['deleteCategory']) && !empty($_GET['deleteCategory'])) {
    $delete = deleteCategory($_GET['deleteCategory']);
    if ($delete) {
        header('location:dashbord.php?listCategory=ok');
    } else {
        header('location:listCategory.php');

    }
} else {
    header('location:../dashbord.php');
}
