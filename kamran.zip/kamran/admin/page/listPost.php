<div class="container" style="margin-top: 10px;">
    <div class="col-sm-12">
        <div class="panel panel-primary">
            <div class="panel-heading">لیست پست های سایت</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr class="success">
                            <th class="text-center">عنوان پست</th>
                            <th class="text-center">زمان ارسال پست</th>
                            <th class="text-center">عملیات</th>
                        </tr>
                        </thead>
                        <tbody>


                        <?php

                            $read = readPostForShowInsPanel();
                            //                        var_dump($read);
                        if (!empty($read)) {
                            for ($i = 0; $i < count($read); $i++) {
                                ?>
                                <tr>
                                    <td class="text-center"><?php echo $read[$i]['title'] ?></td>
                                    <td class="text-center"><?php echo convertToShamsi($read[$i]['time']); ?></td>
                                    <td class="text-center">
                                        <a class="btn btn-warning"
                                           href="?deletepost=<?php echo $read[$i]['id']; ?>">حذف</a>
                                        <a class="btn btn-danger" href="?updatepost=<?php echo $read[$i]['id']; ?>">ویرایش</a>
                                    </td>
                                </tr>
                            <?php }
                        } else {
                            echo '<div class="alert alert-danger">پستی وجود ندارد</div>';
                        } ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
