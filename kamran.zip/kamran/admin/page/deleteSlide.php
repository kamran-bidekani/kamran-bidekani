<?php
$deleteSlider = deleteSLider($_GET['deleteSlide']);
if($deleteSlider){
    header('location:dashbord.php?listSlide=ok');
}
else{

}
?>