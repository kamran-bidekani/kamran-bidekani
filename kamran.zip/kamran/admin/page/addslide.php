<?php
addSlider();
?>
<style>
    .btn-file {
        position: relative;
        overflow: hidden;
    }

    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }
</style>
<form method="post" enctype="multipart/form-data" style="margin-top: 10px;">
    <div class="col-sm-8 col-sm-offset-2">
        <div class="panel panel-primary">
            <div class="panel-heading">

                عکسی را جهت نمایش در اسلایدر اپلود کنید
            </div>
            <div class="panel-body">
                <?php
                if (isset($_GET['addSlide']) && !empty($_GET['addSlide'])) {
                    if ($_GET['addSlide'] == 'error') {
                        echo '<div class="alert alert-danger" style="margin-top: 5px;">پسوند اپلود شده مجاز نمیباشد</div>';
                    }
                    if ($_GET['addSlide'] == 'success') {
                        echo '<div class="alert alert-success" style="margin-top: 5px;">با موفقیت اپلود شد</div>';
                    }
                }
                ?>
                <center>
                <span class="btn btn-primary btn-file">
    انتخاب عکس<input type="file" name="file_upload">
</span>
                </center>
                <button type="submit" name="btnslider" class="btn btn-primary btn-block"
                        style="margin-top: 10px!important;">اپلود
                </button>
            </div>
            <div class="panel-footer">
                حتما یک عکس اپلود شده برای اسلایدر داشته باشید زیرا اگر عکسی نباشد اسلایدر در سایت لود نخواهد شد و با ارور مواجه خواهیم شد
            </div>
        </div>
    </div>
</form>