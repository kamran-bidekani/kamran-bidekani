<?php
include_once 'models/member.php';

if (isset($_GET['editmember']) && !empty($_GET['editmember'])) {
    $id = $_GET['editmember'];
    $memer = readMember($id);
    $editmember = editMember($id);
    if ($editmember == true) {
        header('location:dashbord.php?listmember=ok');
    }
}

?>
<form method="post" style="margin-top: 20px;">
    <div class="col-sm-8 col-sm-offset-2" style="background-color: #fff!important;padding: 10px;">
        <p>نام : </p>
        <div class="form-group">
            <input type="text" class="form-control" name="nameE" value="<?php echo $memer['name']; ?>">
        </div>
        <p>نام خانوادگی : </p>
        <div class="form-group">
            <input type="text" class="form-control" name="lastnameE"
                   value="<?php echo $memer['lastname']; ?>">
        </div>
        <p>یوزر نیم : </p>
        <div class="form-group">
            <input type="text" class="form-control" name="usernameE"
                   value="<?php echo $memer['username']; ?>">
        </div>
        <p>شماره تلفن</p>
        <div class="form-group">
            <input type="number" class="form-control" name="numberE"
                   value="<?php echo $memer['number']; ?>">
        </div>
        <button class="btn btn-primary btn-block" name="btnedit">ویرایش کاربران</button>
    </div>
</form>