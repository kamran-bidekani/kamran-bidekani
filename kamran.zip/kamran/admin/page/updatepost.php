<?php

if (isset($_GET['updatepost']) && !empty($_GET['updatepost'])) {
    $id = $_GET['updatepost'];
}
?>
<style>
    .btn-file {
        position: relative;
        overflow: hidden;
    }

    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }


</style>

<?php
$read = readPostForEditPost($id);
editPost($id,$read['pic']);
?>
<form method="post" enctype="multipart/form-data" style="margin-top: 10px;">
    <div class="col-sm-8 col-sm-offset-2">
        <div class="panel panel-primary">
            <div class="panel-heading">
                ویرایش پست
            </div>
            <div class="panel-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <input type="text" class="form-control" name="titlePostE" style="color: #222222!important;"
                               placeholder="عنوان پست را وارد نمایید" value="<?php echo $read['title']; ?>">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control  ckeditor" name="contentPostE">
                       <?php echo $read['content']; ?>
                        </textarea>
                    </div>
                    <div class="form-group">
                        <select class="form-control" id="sel1" name="categoryEdit"
                                style="color: #222222!important;padding: 2px 5px!important;">
                            <?php
                            $selectCategoryForShowInPenelUpdatePost = selectCategoryForShowInPenelUpdatePost();
                            foreach ($selectCategoryForShowInPenelUpdatePost as $value) {
                                ?>
                                <option value="<?php echo $value['id']; ?>"
                                        style="color: #222222!important;" <?php if ($read['category'] == $value['id']) {
                                    echo 'selected';
                                } ?>><?php echo $value['name']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="linkFileE" style="color: #222222!important;"
                               placeholder="لینک فایل مورد نظر خود را وارد نمایید"
                               value="<?php echo $read['linkfile']; ?>">
                    </div>
                    <div class="uploadfile">
                        <p style="color: #222222">عکسی را جهت نمایش در سایت آپلود نمایید .</p>
                        <img src="<?php echo 'img/post/'.$read['pic']?>" class="img-responsive" style="width: 75px;height: 75px;margin: 5px;">
                        <center>
                     <span class="btn btn-danger btn-file"
                           style="margin: 5px 25px 14px 25px;border-radius: 0!important;">
                         انتخاب عکس<input type="file" name="file_uploadeE">
                      </span>
                        </center>
                    </div>
                </form>
                <button type="submit" name="btnEditPost" class="btn btn-primary btn-block">ویرایش پست</button>
            </div>
        </div>
    </div>
</form>