<?php
addElanat();
?>
<div class="col-sm-8 col-sm-offset-2">
    <div class="panel panel-primary" style="margin-top: 20px;">
        <div class="panel-heading">افزودن اعلانات به سایت</div>
        <div class="panel-body">
            <form method="post">
                <div class="form-group">
                    <input placeholder="اعلانات خود را در این قسمت وارد نمایید" style="color: #222222" name="elanat" class="form-control">
                </div>
                <button class="btn btn-primary btn-block" type="submit" name="btnelanat">افزودن</button>
            </form>
        </div>
    </div>
</div>