<style>
    .btn-file {
        position: relative;
        overflow: hidden;
    }

    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }

    input::placeholder {
        color: #222222 !important;
    }

</style>
<?php
$selectCategoryForShowInPenelSendPost = selectCategoryForShowInPenelSendPost();
addPost();
?>
<form method="post" enctype="multipart/form-data" style="margin-top: 10px;">
    <div class="col-sm-8 col-sm-offset-2">
        <div class="panel panel-primary">
            <div class="panel-heading">
                ارسال پست
            </div>
            <div class="panel-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <input type="text" class="form-control" name="titlePost" style="color: #222222!important;"
                               placeholder="عنوان پست را وارد نمایید">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control  ckeditor" name="content">

                        </textarea>
                    </div>
                    <?php
                    if($selectCategoryForShowInPenelSendPost == null){
                        echo "<div class='alert alert-danger text-center my-3'>"."ابتدا یک دسته بندی ایجاد کنید"."</div>";
                    }
                    ?>
                    <div class="form-group">
                        <select class="form-control" id="sel1" name="categoryShow"
                                style="color: #222222!important;padding: 2px 5px!important;">
                            <?php
                            foreach ($selectCategoryForShowInPenelSendPost as $value) {
                                ?>
                                <option value="<?php echo $value['id']; ?>"
                                        style="color: #222222!important;"><?php echo $value['name']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="linkFile" style="color: #222222!important;"
                        placeholder="آدرس فایل را وارد کنید" required >
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="info" style="color: #222222!important;"
                        placeholder="نام نویسنده را وارد کنید" required>
                    </div>
                    <div class="uploadfile">
                        <p style="color: #222222">عکسی را جهت نمایش در سایت آپلود نمایید .</p>
                        <center>
                     <span class="btn btn-danger btn-file"
                           style="margin: 5px 25px 14px 25px;border-radius: 0!important;">
                         انتخاب عکس<input type="file" name="file_upload">
                      </span>
                        </center>
                    </div>
                </form>
                <button type="submit" name="btnPost" class="btn btn-primary btn-block">ارسال پست</button>
            </div>
        </div>
    </div>
</form>