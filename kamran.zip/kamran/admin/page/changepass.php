<?php
changepassword();
?>
<div class="col-sm-8 col-sm-offset-2">
    <div class="panel panel-primary" style="margin-top: 10px;">
        <div class="panel-heading">
            تغییر پسورد مدیریت
        </div>
        <div class="panel-body">
            <form method="post">
                <div class="form-group">
                    <input type="password" name="oldpassword" placeholder="پسورد قدیمی را وارد نمایید"
                           class="form-control">
                </div>
                <div class="form-group">
                    <input type="password" name="newpassword" placeholder="پسورد جدید را وارد نمایید"
                           class="form-control">
                </div>
                <div class="form-group">
                    <input type="password" name="againnewpassword" placeholder="پسورد جدید را مجدد وارد نمایید"
                           class="form-control">
                </div>
                <button type="submit" name="btnchangepassword" class="btn btn-block btn-primary">تغییر پسورد</button>
            </form>
        </div>
    </div>
</div>