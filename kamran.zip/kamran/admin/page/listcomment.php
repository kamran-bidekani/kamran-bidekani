<div class="container">
    <div class="row">
        <div class="col-sm-12" style="margin-top: 18px;">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    لیست نظرات
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>ایدی</th>
                                <th>پست مربوط به نظر</th>
                                <th>کامنت ارسالی</th>
                                <th>نام ارسال کننده</th>
                                <th>تایید نظر</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $listComment = listComment();
                            if (!empty($listComment)) {
                                foreach ($listComment as $value) {
                                    $id = $value['id'];
                                    ?>
                                    <tr>
                                        <td><?php echo $value['id']; ?></td>
                                        <td><?php echo $value['title']; ?></td>
                                        <td><?php echo $value['content']; ?></td>
                                        <td><?php echo $value['info']; ?></td>
                                        <form method="post">
                                            <td>
                                                <?php if ($value['status'] == 1) {
                                                    echo '<p>نظر تایید شده است</p>';
                                                } else { ?>
                                                    <a href="taeednazar.php?id=<?php echo $value['id']; ?>"
                                                       class="btn btn-primary" style="border-radius: 0!important;"
                                                       name="taeednazar">تایید نظر
                                                    </a>
                                                <?php } ?>
                                            </td>
                                        </form>
                                    </tr>
                                <?php }
                            } else {
                                echo '<p class="alert alert-warning">نظری وجود ندارد</p>';
                            } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="panel panel-success">
                <div class="panel-heading">
                    پاسخ به نظرات
                </div>
                <div class="panel-body">
                    <div class="col-sm-8 col-sm-offset-2">
                        <?php
                        answercomment();
                        ?>
                        <form method="post">
                            <div class="form-group">
                                <input style="color: #222" type="text" name="idanswercomment" class="form-control"
                                       placeholder="ایدی نظری که میخواهید به ان پاسخ دهید را وارد نمایید">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" rows="5" id="comment" name="commentanswercomment"
                                          placeholder="پاسخ خود را در این قسمت وارد نمایید"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block" name="btnanswercomment">ارسال پاسخ
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <br/>
            <br/>
        </div>
    </div>
</div>