<?php
$readLogForShowInPanel = readLogForShowInPanel();
?>
<div class="container" style="margin-top: 10px;">
    <div class="col-sm-12">
        <p style="font-size: 19px;font-weight: bold">لاگ کاربران</p>
        <div class="panel panel-primary">
            <div class="panel-heading">
                لاگ کاربران
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr class="success">
                            <th class="text-center">ایدی</th>
                            <th class="text-center">ایپی</th>
                            <th class="text-center">یوزر نیم کاربر</th>
                            <th class="text-center">تاریخ</th>
                            <th class="text-center">توضیحات</th>
                            <th class="text-center">حذف</th>
                        </tr>
                        </thead>
                        <?php
                        if (!empty($readLogForShowInPanel)) {
                            foreach ($readLogForShowInPanel as $values) {
                                ?>
                                <tbody>
                                <tr>
                                    <td class="text-center"><?php echo $values['id']; ?></td>
                                    <td class="text-center"><?php echo $values['ip']; ?></td>
                                    <td class="text-center"><?php echo $values['username']; ?></td>
                                    <td class="text-center"><?php echo $values['time']; ?></td>
                                    <td class="text-center"><?php echo $values['detailes']; ?></td>
                                    <td class="text-center"><a
                                                href="<?php echo 'page/deleteLog.php?id=' . $values['id'] ?>">حذف</a></td>
                                </tr>
                                </tbody>
                            <?php }
                        } else {
                            echo '<br/>';
                            echo '<div class="alert alert-warning" style="margin-top: 10px!important;">';
                            echo 'لاگی وجود ندارد';
                            echo '</div>';
                        } ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
