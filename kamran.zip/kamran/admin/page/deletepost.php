<?php
if (isset($_GET['deletepost']) && !empty($_GET['deletepost'])) {
    $id = $_GET['deletepost'];
}

$deletePost = deletePost($id);
if ($deletePost) {
    header('location:dashbord.php?listPost=ok');
}