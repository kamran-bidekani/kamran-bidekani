<?php
$members = showListMembers();
?>
<div class="container" style="margin-top: 10px;">
    <div class="col-sm-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                لیست کاربران سایت
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr class="success">
                            <th class="text-center">ایدی</th>
                            <th class="text-center">نام</th>
                            <th class="text-center">نام خانوادگی</th>
                            <th class="text-center">یوزر نیم</th>
                            <th class="text-center">شماره تلفن</th>
                            <th class="text-center">حذف</th>
                            <th class="text-center">ویرایش</th>
                        </tr>
                        </thead>
                        <?php
                        if (!empty($members)) {
                            foreach ($members as $values) {
                                ?>
                                <tbody>
                                <tr>
                                    <td class="text-center"><?php echo $values['id']; ?></td>
                                    <td class="text-center"><?php echo $values['name']; ?></td>
                                    <td class="text-center"><?php echo $values['lastname']; ?></td>
                                    <td class="text-center"><?php echo $values['username']; ?></td>
                                    <td class="text-center"><?php echo $values['number']; ?></td>
                                    <td class="text-center"><a class=""
                                                               href="<?php echo 'page/deleteMember.php?id=' . $values['id'] ?>">پاک
                                            کردن</a></td>
                                    <td class="text-center"><a class=""
                                                               href="<?php echo 'dashbord.php?editmember='.$values['id'] ?>">ویرایش
                                            کردن</a></td>
                                </tr>
                                </tbody>
                            <?php }
                        } else {
                            echo '<br/>';
                            echo '<div class="alert alert-warning" style="margin-top: 10px!important;">';
                            echo 'کاربری داخل سایت ثبت نام نکرده است';
                            echo '</div>';
                        } ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
