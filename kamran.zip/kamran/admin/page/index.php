<?php
$count = countPost();
$countmember = countMember();
?>
<div class="col-sm-4" style="margin-top: 10px;">
    <div class="panel panel-primary">
        <div class="panel-heading">تعداد کاربران</div>
        <div class="panel-body">
            <p>تعداد کاربران : <?php echo $countmember[0]['COUNT(id)']; ?></p>
        </div>
    </div>
</div>
<div class="col-sm-4" style="margin-top: 10px">
    <div class="panel panel-primary">
        <div class="panel-heading">تعداد پست ها</div>
        <div class="panel-body">

            <p>تعداد پست ها : <?php echo $count[0]['COUNT(id)']; ?></p>
        </div>
    </div>
</div>
