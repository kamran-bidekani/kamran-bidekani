<?php
$listslider = listSlider()
?>
<div class="container" style="margin-top: 10px;">
    <div class="col-sm-12">
        <div class="panel panel-primary">
            <div class="panel-heading">لیست اسلایدر ها</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr class="success">
                            <th class="text-center">ایدی</th>
                            <th class="text-center"> نام اسلایدر به لاتین</th>
                            <th class="text-center">عملیات</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php
                        if (!empty($listslider)) {
                            foreach ($listslider as $value) {
                                ?>
                                <tr>
                                    <td class="text-center"><?php echo $value['id']; ?></td>
                                    <td class="text-center"><?php echo $value['slidename']; ?></td>
                                    <td class="text-center"><a
                                                href="<?php echo 'dashbord.php?deleteSlide=' . $value['id'] ?>">حذف</a>
                                    </td>
                                </tr>
                            <?php }
                        } else {

                        } ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
