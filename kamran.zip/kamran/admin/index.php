<?php
require_once 'models/loginCode.php';
loginToPanel();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="img/favicon.html">
    <title>اسکریپت مدیریت محتوا</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet"/>
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet"/>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
</head>
<body class="login-body">
<div class="container">


    <form class="form-signin" action="" method="post" style="margin-top: 20px!important;">
        <h2 class="form-signin-heading">همین حالا وارد شوید</h2>
        <div class="login-wrap">
            <?php
            if (isset($_GET['Login']) && !empty($_GET['Login'])) {
                ?>
                <div class="alert alert-warning">
                    یوزرنیم یا پسورد اشتباه میباشد
                </div>
            <?php } ?>

            <?php
            if (isset($_GET['First']) && !empty($_GET['First'])) {
                ?>
                <div class="alert alert-warning">
                    برای ورود به پنل ابتدا لاگین کنید !!
                </div>
            <?php } ?>
            <input type="text" class="form-control" placeholder="نام کاربری" name="username" autofocus>
            <input type="password" class="form-control" name="password" placeholder="کلمه عبور">
            <button class="btn btn-lg btn-login btn-block" type="submit" name="btn">ورود</button>
        </div>
    </form>
</div>
</body>
</html>
