<?php

include_once 'models/loginCode.php';
include_once 'models/category.php';
include_once 'models/slider.php';
include_once 'models/post.php';
include_once 'models/options.php';
include_once 'models/comment.php';
include_once '../jdf.php';
if (isset($_SESSION['checkLogin'])) {

} else {
    header('location:index.php?First=Login');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="img/favicon.html">

    <title>پنل مدیریت</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet"/>
    <link href="assets/jquery-file-upload/css/jquery.fileupload-ui.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet"/>


    <?php ?>


<body>

<section id="container" class="">
    <!--header start-->
    <header class="header white-bg">
        <div class="sidebar-toggle-box">
            <div data-original-title="بستن | باز کردن منو" data-placement="left" class="icon-reorder tooltips"></div>
        </div>

        <div>
            <p style="margin-top: 19px;font-size: 17px;">کامران بیدکانی هستم توسعه دهنده این سایت</p>
        </div>

        <div class="pull-left">
            <a href="exit.php" class="btn btn-danger" style="margin-top: -54px;border-radius: 0;">خروج از پنل</a>
            <a href="<?php echo Address_MySite; ?>" target="_blank" class="btn btn-danger"
               style="margin-top: -54px;border-radius: 0;">نمایش
                سایت</a>
        </div>
    </header>
    <!--header end-->
    <!--sidebar start-->
    <aside>
        <div id="sidebar" class="nav-collapse ">
            <!-- sidebar menu start-->
            <br/><br/>
            <ul class="sidebar-menu">
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon-book"></i>
                        <span style="color: #FFFFFF!important;font-size: 12px;">اطلاعات سایت</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="<?php echo 'dashbord.php?index=ok' ?>">مشاهده ی اطلاعات</a></li>
                    </ul>
                </li>

                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon-book"></i>
                        <span style="color: #FFFFFF!important;font-size: 12px;">مدیریت کاربران</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="<?php echo 'dashbord.php?listmember=ok' ?>">لیست کاربران</a></li>
                        <li><a class="" href="<?php echo 'dashbord.php?logmember=ok' ?>">لاگ کاربران</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon-book"></i>
                        <span style="color: #FFFFFF!important;font-size: 12px;">مدیریت دسته بندی</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="<?php echo 'dashbord.php?addCategory=ok' ?>">افزودن دسته بندی</a></li>
                        <li><a class="" href="<?php echo 'dashbord.php?listCategory=ok' ?>">لیست دسته بندی</a></li>
                    </ul>
                </li>

                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon-book"></i>
                        <span style="color: #FFFFFF;font-size: 12px;">مدیریت اسلایدر</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="<?php echo 'dashbord.php?addSlide=ok' ?>">افزودن اسلاید</a></li>
                        <li><a class="" href="<?php echo 'dashbord.php?listSlide=ok' ?>">لیست اسلاید</a></li>
                    </ul>
                </li>

                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon-book"></i>
                        <span style="color: #FFFFFF;font-size: 12px;">مدیریت پست</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="<?php echo 'dashbord.php?addPost=ok' ?>">افزودن پست</a></li>
                        <li><a class="" href="<?php echo 'dashbord.php?listPost=ok' ?>">لیست پست ها</a></li>
                    </ul>
                </li>

                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon-book"></i>
                        <span style="color: #FFFFFF;font-size: 12px;">مدیریت نظرات</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="<?php echo 'dashbord.php?listcomment=ok' ?>">لیست نظرات</a></li>
                    </ul>
                </li>


                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon-book"></i>
                        <span style="color: #FFFFFF;font-size: 12px;">تنظیمات</span>
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="<?php echo 'dashbord.php?changepass=ok' ?>">تغییر پسورد</a></li>
                        <li><a class="" href="<?php echo 'dashbord.php?addelanat=ok' ?>">افزودن اعلانات</a></li>
                    </ul>
                </li>
            </ul>
            <!-- sidebar menu end-->
        </div>
    </aside>
    <!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <?php
            if (isset($_GET['listmember']) && !empty($_GET['listmember'])) {
                include_once 'page/listMember.php';
            }

            if (isset($_GET['addPost']) && !empty($_GET['addPost'])) {
                include_once 'page/addPost.php';
            }

            if (isset($_GET['listPost']) && !empty($_GET['listPost'])) {
                include_once 'page/listPost.php';
            }
            if (isset($_GET['editmember']) && !empty($_GET['editmember'])) {
                include_once 'page/editMember.php';
            }
            if (isset($_GET['logmember']) && !empty($_GET['logmember'])) {
                include_once 'page/logmember.php';
            }
            if (isset($_GET['addCategory']) && !empty($_GET['addCategory'])) {
                include_once 'page/addCategory.php';
            }
            if (isset($_GET['listCategory']) && !empty($_GET['listCategory'])) {
                include_once 'page/listCategory.php';
            }

            if (isset($_GET['deleteCategory']) && !empty($_GET['deleteCategory'])) {
                include_once 'page/deleteCategory.php';
            }
            if (isset($_GET['addSlide']) && !empty($_GET['addSlide'])) {
                include_once 'page/addslide.php';
            }
            if (isset($_GET['index']) && !empty($_GET['index'])) {
                include_once 'page/index.php';
            }
            if (isset($_GET['listSlide']) && !empty($_GET['listSlide'])) {
                include_once 'page/listslide.php';
            }
            if (isset($_GET['deleteSlide']) && !empty($_GET['deleteSlide'])) {
                include_once 'page/deleteSlide.php';
            }
            if (isset($_GET['deletepost']) && !empty($_GET['deletepost'])) {
                include_once 'page/deletepost.php';
            }

            if (isset($_GET['updatepost']) && !empty($_GET['updatepost'])) {
                include_once 'page/updatepost.php';
            }
            if (isset($_GET['changepass']) && !empty($_GET['changepass'])) {
                include_once 'page/changepass.php';
            }
            if (isset($_GET['addelanat']) && !empty($_GET['addelanat'])) {
                include_once 'page/addelanat.php';
            }
            if (isset($_GET['listcomment']) && !empty($_GET['listcomment'])) {
                include_once 'page/listcomment.php';
            }
            ?>

        </section>
    </section>
    <!--main content end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--<script src="js/jquery.scrollTo.min.js"></script>-->
<!--<script src="js/jquery.nicescroll.js" type="text/javascript"></script>-->
<script src="js/ckeditor/ckeditor.js"></script>
<!-- BEGIN:File Upload Plugin JS files-->
<script src="assets/jquery-file-upload/js/vendor/jquery.ui.widget.js"></script>
<!-- The Templates plugin is included to render the upload/download listings -->
<script src="assets/jquery-file-upload/js/vendor/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="assets/jquery-file-upload/js/vendor/load-image.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="assets/jquery-file-upload/js/vendor/canvas-to-blob.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="assets/jquery-file-upload/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="assets/jquery-file-upload/js/jquery.fileupload.js"></script>
<!-- The File Upload file processing plugin -->
<script src="assets/jquery-file-upload/js/jquery.fileupload-fp.js"></script>
<!-- The File Upload user interface plugin -->
<script src="assets/jquery-file-upload/js/jquery.fileupload-ui.js"></script>

<script src="//cdn.ckeditor.com/4.11.1/full/ckeditor.js"></script>

<!--common script for all pages-->
<script src="js/common-scripts.js"></script>


</body>
</html>
