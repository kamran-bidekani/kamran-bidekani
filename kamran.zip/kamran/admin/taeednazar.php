<?php
session_start();
if (isset($_SESSION['checkLogin'])) {
    include_once 'models/loginCode.php';
    include_once 'models/category.php';
    include_once 'models/slider.php';
    include_once 'models/post.php';
    include_once 'models/options.php';
    include_once 'models/comment.php';
    include_once '../jdf.php';
    taeedNazar($_GET['id']);

} else {
    header('location:index.php?First=Login');
}

?>