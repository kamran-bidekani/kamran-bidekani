<?php

function listComment()
{
    global $database;
    $result = $database->prepare('SELECT * FROM comments');
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}


function taeedNazar($id)
{
    global $database;
    $result = $database->prepare('UPDATE comments SET status=? WHERE id=?');
    $result->bindValue(1, 1);
    $result->bindValue(2, $id);
    $result->execute();
    header('location:http://localhost/kamran/admin/dashbord.php?listcomment=ok');
}


function answercomment()
{
    global $database;
    if (isset($_POST['btnanswercomment'])) {
        $sql = 'INSERT INTO answercomment SET content=?,idcomment=?';
        $result = $database->prepare($sql);
        $result->bindValue(1, $_POST['commentanswercomment']);
        $result->bindValue(2, $_POST['idanswercomment']);
        $result->execute();
    }
}

?>