<?php
include_once 'db.php';
function readMember($id)
{
    global $database;
    $sql = 'SELECT * FROM members where id=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

function editMember($id)
{
    global $database;
    if (isset($_POST['btnedit'])) {
        $sql = 'UPDATE members SET name=?,lastname=?,username=?,number=? WHERE id=?';
        $result = $database->prepare($sql);
        $result->bindValue(1, $_POST['nameE']);
        $result->bindValue(2, $_POST['lastnameE']);
        $result->bindValue(3, $_POST['usernameE']);
        $result->bindValue(4, $_POST['numberE']);
        $result->bindValue(5, $id);
        $result->execute();
        if ($result->rowCount() >= 1) {
            return $result;
        } else {
            return false;
        }
    }
}




?>