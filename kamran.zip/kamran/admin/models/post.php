<?php
function selectCategoryForShowInPenelSendPost()
{
    global $database;
    $sql = 'SELECT * FROM category_tbl';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

function addPost()
{
    global $database;
    if (isset($_POST['btnPost'])) {
        $picname = $_FILES['file_upload']['name'];
        $tmp_pic = $_FILES['file_upload']['tmp_name'];
        $exp = explode('.', $picname);
        $passwand = end($exp);
        if (in_array($passwand, array('png', 'jpeg', 'jpg'))) {
            $newName = rand(1, 200) . 'picPost' . '.' . $passwand;
            move_uploaded_file($tmp_pic, 'img/post/' . $newName);
            $sql = 'INSERT INTO post SET title=?,content=?,linkfile=?,pic=?,category=?,writer=?';
            $result = $database->prepare($sql);
            $result->bindValue(1, $_POST['titlePost']);
            $result->bindValue(2, $_POST['content']);
            $result->bindValue(3, $_POST['linkFile']);
            $result->bindValue(4, $newName);
            $result->bindValue(5, $_POST['categoryShow']);
            $result->bindValue(6, $_POST['info']);
            $result->execute();
        }


    }
}


function readPostForShowInsPanel()
{
    global $database;
    $sql = 'SELECT * FROM post';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

function convertToShamsi($date)
{
    $level1 = explode(' ', $date);
//    var_dump($level1);
//    die();
    list($year, $month, $day) = explode('-', $level1[0]);
    list($hour, $min, $second) = explode(':', $level1[1]);
    $timestamp = mktime($hour, $min, $second, $month, $day, $year);
    return jdate('تاریخ : Y/m/d  ساعت : H:i:s', $timestamp);
}

function readPostForEditPost($id)
{
    global $database;
    $sql = 'SELECT * FROM post WHERE id=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

function selectCategoryForShowInPenelUpdatePost()
{
    global $database;
    $sql = 'SELECT * FROM category_tbl';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}


function editPost($id, $picfile = '')
{
    if (isset($_POST['btnEditPost'])) {
        $filename = $_FILES['file_uploadeE']['name'];
        $filetmp = $_FILES['file_uploadeE']['tmp_name'];
        $filenameExplode = explode('.', $filename);
        $passwand = end($filenameExplode);
        if (in_array($passwand, array('png', 'jpeg', 'jpg', ''))) {
            if (!empty($newName) && isset($newName)) {
                $newName = 'Editpic' . rand(1, 1000) . '.' . $passwand;
            } else {
                $newName = $picfile;
            }
            move_uploaded_file($filetmp, 'img/post/' . $newName);


            global $database;
            $sql = 'UPDATE post SET title=?,content=?,linkfile=?,category=?,pic=? WHERE id=?';
            $result = $database->prepare($sql);
            $result->bindValue(1, $_POST['titlePostE']);
            $result->bindValue(2, $_POST['contentPostE']);
            $result->bindValue(3, $_POST['linkFileE']);
            $result->bindValue(4, $_POST['categoryEdit']);

            $result->bindValue(5, $newName);
            $result->bindValue(6, $id);
            if ($result->execute()) {
                header('location:dashbord.php?listPost=ok');
            }
        }
    }
}


function deletePost($id)
{
    global $database;
    $sql = 'DELETE FROM post WHERE id=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result;
    } else {
        return false;
    }
}

function countPost()
{
    global $database;
    $sql = 'SELECT COUNT(id) FROM post';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }

}

function countMember()
{
    global $database;
    $sql = 'SELECT COUNT(id) FROM members';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }

}


?>