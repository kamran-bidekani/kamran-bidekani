<?php

include_once 'db.php';
function loginToPanel()
{
    global $database;
    if (isset($_POST['btn'])) {
        $check = 'SELECT * FROM admin_tbl WHERE username=? and password=?';
        $result = $database->prepare($check);
        $result->bindValue(1, $_POST['username']);
        $result->bindValue(2, md5($_POST['password']));
        $result->execute();
        if ($result->rowCount() >= 1) {
            $row = $result->fetch(PDO::FETCH_ASSOC);
            $_SESSION['checkLogin'] = $_POST['username'];
            $_SESSION['info'] = $row['info'];
            header('location:dashbord.php');
            return $result;
        } else {
            header('location:index.php?Login=error');
            return false;
        }
    }
}

function showListMembers()
{
    global $database;
    $sql = 'SELECT * FROM members';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}


function readLogForShowInPanel()
{
    global $database;
    $sql = 'SELECT * FROM log_tbl';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }

}

?>