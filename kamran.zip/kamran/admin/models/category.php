<?php

function addCategory()
{
    global $database;
    if (isset($_POST['btnaddCategory'])) {
        $sql = 'INSERT INTO category_tbl SET name=?,slug=?';
        $result = $database->prepare($sql);
        $result->bindValue(1, $_POST['addcategoryF']);
        $result->bindValue(2, $_POST['addcategoryE']);
        if ($result->execute()) {
            return $result;
        } else {
            return false;
        }
    }
}

function listCategory()
{
    global $database;
    $sql = 'SELECT * FROM category_tbl';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result->fetchAll(PDO::FETCH_ASSOC);
    } else {
        return false;
    }
}

function deleteCategory($id)
{
    global $database;
    $result = $database->prepare('DELETE FROM category_tbl WHERE id=?');
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result;
    } else {
        return false;
    }

}

?>