<?php


function checkoldpassword($password)
{
    global $database;
    $result = $database->prepare('SELECT * FROM admin_tbl WHERE password=?');
    $result->bindValue(1, md5($password));
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result;
    } else {
        return false;
    }
}

function changepassword()
{
    global $database;
    if (isset($_POST['btnchangepassword'])) {
        $oldpassword = $_POST['oldpassword'];
        $newpassword = $_POST['newpassword'];
        $againnewpassword = $_POST['againnewpassword'];

        if (checkoldpassword($oldpassword)) {
            if ($newpassword == $againnewpassword) {
                $sql = 'UPDATE admin_tbl SET password=? where password=?';
                $result = $database->prepare($sql);
                $result->bindValue(1, md5($newpassword));
                $result->bindValue(2, md5($oldpassword));
                if ($result->execute()) {
                    echo '<div style="margin-top: 15px;margin-right: 20px;margin-left: 20px;" class="alert alert-success">پسورد با موفقیت تغییر یافت</div>';
                } else {
                    echo '<div style="margin-top: 15px;margin-right: 20px;margin-left: 20px;" class="alert alert-danger">تغییر پسورد با مشکل مواجه شد لطفا مجدد تست نمایید</div>';
                }
            } else {
                echo '<div style="margin-top: 15px;margin-right: 20px;margin-left: 20px;" class="alert alert-warning">پسورد جدید با تکرار پسورد جدید یک سان نمیباشد لطفا مجدد وارد نمایید</div>';
            }
        } else {
            echo '<div style="margin-top: 15px;margin-right: 20px;margin-left: 20px;" class="alert alert-warning">پسورد قدیمی را  درست وارد نکرده اید لطفا مجدد تست کنید</div>';
        }
    }
}

function addElanat()
{
    global $database;
    if (isset($_POST['btnelanat'])) {
        $sql = 'INSERT INTO elanat_tbl SET elanat=?';
        $result = $database->prepare($sql);
        $result->bindValue(1, $_POST['elanat']);
        $result->execute();
    }
}



?>