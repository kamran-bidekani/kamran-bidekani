<?php
session_start();
date_default_timezone_set('Asia/Tehran');
ob_start();
define('DB_NAME', 'kamran');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('Address_MySite', 'http://localhost/kamran');
$Options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'set names UTF8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING
);
//Etesal Be Database;
$database = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, $Options);

?>