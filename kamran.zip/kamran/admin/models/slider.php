<?php
function addSlider()
{
    global $database;
    if (isset($_POST['btnslider'])) {
        @$file = $_FILES['file_upload'];
        $filename = $file['name'];
        $filetmp = $file['tmp_name'];
        $exp = explode('.', $filename);
        $passwand = end($exp);
        if (in_array($passwand, array('png', 'jpg', 'jpeg'))) {
            $newname = 'sliderpic' . rand(1, 1000) . '.' . $passwand;
            move_uploaded_file($filetmp, 'img/slider/' . $newname);
            $sql = 'INSERT INTO slider SET slidename=?';
            $result = $database->prepare($sql);
            $result->bindValue(1, $newname);
            $result->execute();
            header('location:dashbord.php?addSlide=success');
        } else {
            header('location:dashbord.php?addSlide=error');
        }

    }
}

function listSlider()
{
    global $database;
    $sql = 'SELECT * FROM slider';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result->fetchAll(PDO::FETCH_ASSOC);
    } else {
        return false;
    }
}

function deleteSLider($id)
{
    global $database;
    $sql = 'DELETE FROM slider WHERE id=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result;
    } else {
        return false;
    }
}

?>