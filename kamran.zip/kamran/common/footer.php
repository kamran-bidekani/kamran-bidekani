<footer>
    <div class="container">
        <div class="col-sm-4 text-center">
            <h2>پست های ارسال شده</h2>
            <?php
            $showlastpost =showlastpost();
            if(!empty($showlastpost) && is_array($showlastpost)){
                foreach ($showlastpost as $value){
            ?>
            <p class="f"><?php echo $value['title'];?></p>
           <?php }
            }
           ?>
        </div>
        <div class="col-sm-4 text-center">
            <h2>ارتباط با ما</h2>
            <p class="f">شماره موبایل : 09136317565</p>
        </div>
        <div class="col-sm-4 text-center">
            <h2>اعلانات</h2>
            <?php
            $readElanat = readElanat();
            ?>
            <p class="f"><?php 
            if(!empty($readElanat['elanat'])){
                echo $readElanat['elanat']; 
            }
            ?></p>
            <?php ?>
        </div>
    </div>
</footer>
<div style="background-color: #484848;padding: 5px;text-align: center">
    <p style="color: #ffffff">طراحی قالب توسط کامران بیدکانی </p>
</div>
<script src="files/js/jquery.min.1.11.2.js"></script>
<script src="files/js/bootstrap.min.js"></script>
</body>
</html>