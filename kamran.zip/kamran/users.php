<?php require_once 'common/header.php'; ?>
<?php
include_once 'models_code/login_register.php';
registerInSite();
loginToSite(@$_POST['usernameL'],@$_POST['passwordL'])
?>
    <div class="container m30top">
        <div class="col-sm-6">
            <div class="panel panel-primary">
                <div class="panel-heading">ثبت نام در سایت</div>
                <form method="post">
                    <div class="panel-body">
                        <?php if (isset($_GET['input']) && !empty($_GET['input'])) { ?>
                            <div class="alert alert-warning" style="line-height: 22px;">
                                یوزرنیم یا پسورد یا نام یا نام خانوادگی یا شماره تلفن یا همگی یا ..خالی هستند لطفا تمامی
                                اینپوت ها رو پر نمایید
                            </div>
                        <?php } ?>

                        <?php if (isset($_GET['register']) && !empty($_GET['register'])) { ?>
                            <div class="alert alert-warning" style="line-height: 22px;">
                                ثبت نام با مشکل مواجه شد
                            </div>
                        <?php } ?>

                        <?php if (isset($_GET['registersuccess']) && !empty($_GET['registersuccess'])) { ?>
                            <div class="alert alert-success" style="line-height: 22px;">
                                ثبت نام باموفقیت انجام شد
                            </div>
                        <?php } ?>

                        <?php if (isset($_GET['username']) && !empty($_GET['username'])) { ?>
                            <div class="alert alert-warning" style="line-height: 22px;">
                                یوزرنیم در سایت موجود میباشد لطفا یوزر نیم دیگری را انتخاب نمایید
                            </div>
                        <?php } ?>
                        <div class="form-group">
                            <input type="text" class="form-control" name="name" placeholder="نام خود را به فارسی وارد نمایید">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="lastname"
                                   placeholder="فامیل خود را  به فارسی وارد نمایید">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="usernameR"
                                   placeholder="یوزر نیم خود را به لاتین وارد نمایید">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="passwordR"
                                   placeholder="پسورد را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control" name="number"
                                   placeholder="شماره تلفن خود را به لاتین  وارد نمایید">
                        </div>

                        <button class="btn btn-primary btn-block" name="btnR">ثبت نام در سایت</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="panel panel-success">
                <div class="panel-heading">ورود به سایت</div>
                <form method="post">
                    <div class="panel-body">
                        <?php if (isset($_GET['loginSite']) && !empty($_GET['loginSite'])) { ?>
                            <div class="alert alert-warning" style="line-height: 22px;">
                                یوزر نیم یا پسورد اشتباه میباشد
                            </div>
                        <?php } ?>
                        <div class="form-group">
                            <input type="text" class="form-control" name="usernameL"
                                   placeholder="یوزر نیم را وارد نمایید">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="passwordL"
                                   placeholder="پسورد را وارد نمایید">
                        </div>

                        <button class="btn btn-block btn-success" name="btnL">ورود به سایت</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
<?php require_once 'common/footer.php'; ?>