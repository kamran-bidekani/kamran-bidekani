<?php
function search($title)
{
    global $database;
    $result = $database->prepare('SELECT * FROM post WHERE title LIKE ?');
    $result->bindValue(1, "%$title%");
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

?>


