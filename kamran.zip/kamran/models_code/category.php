<?php

function showCategory()
{
    global $database;
    $sql = 'SELECT * FROM category_tbl';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

?>