<?php

function postmortabet($category, $id)
{
    global $database;
    $result = $database->prepare('SELECT * FROM post WHERE category=? AND id <> ? LIMIT 3');
    $result->bindValue(1, $category);
    $result->bindValue(2, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

?>