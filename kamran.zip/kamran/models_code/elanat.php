<?php
function readElanat()
{
    global $database;
    $sql = 'SELECT * FROM elanat_tbl   ORDER BY id DESC limit 1';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return $row;
    }
}


function showlastpost()
{
    global $database;
    $sql = 'SELECT * FROM post ORDER BY id DESC limit 3';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

?>