<?php
function showPostForShowInSite()
{
    global $database;
    $sql = 'SELECT * FROM post ORDER BY id DESC ';
    $result = $database->prepare($sql);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

function showPostForEdameMatlab($id)
{
    global $database;
    $sql = 'SELECT * FROM post WHERE id=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

function showCategoryById($id)
{
    global $database;
    $sql = 'SELECT * FROM category_tbl where id=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result->fetch(PDO::FETCH_ASSOC);
    } else {
        return false;
    }
}


function convertToShamsi($date)
{
    $level1 = explode(' ', $date);
//    var_dump($level1);
//    die();
    list($year, $month, $day) = explode('-', $level1[0]);
    list($hour, $min, $second) = explode(':', $level1[1]);
    $timestamp = mktime($hour, $min, $second, $month, $day, $year);
    return jdate('تاریخ : Y/m/d  ساعت : H:i:s', $timestamp);
}

?>