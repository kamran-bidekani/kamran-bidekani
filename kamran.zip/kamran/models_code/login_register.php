<?php

function checkUserName()
{
    global $database;
    $sql = 'SELECT * FROM members WHERE username=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $_POST['usernameR']);
    $result->execute();
    if ($result->rowCount() >= 1) {
        return $result;
    } else {
        return false;
    }
}

function registerInSite()
{
    global $database;
    if (isset($_POST['btnR'])) {
        if (!empty($_POST['usernameR']) && !empty($_POST['passwordR']) && !empty($_POST['name']) && !empty($_POST['lastname']) && !empty($_POST['number'])) {
            if (checkUserName() == true) {
                header('location:users.php?username=exists');
            } else {
                $sql = 'INSERT INTO members SET name=?,lastname=?,username=?,password=?,number=?';
                $result = $database->prepare($sql);
                $result->bindValue(1, $_POST['name']);
                $result->bindValue(2, $_POST['lastname']);
                $result->bindValue(3, $_POST['usernameR']);
                $result->bindValue(4, sha1($_POST['passwordR']));
                $result->bindValue(5, $_POST['number']);
                $result->execute();
                if ($result->execute()) {
                    header('location:users.php?registersuccess=ok');
                    return $result;
                } else {
                    header('location:users.php?register=error');
                    return false;
                }
            }
        } else {
            header('location:users.php?input=empty');
        }
    }
}


function loginToSite($username, $password)
{
    global $database;
    if (isset($_POST['btnL'])) {
        $sql = 'SELECT * FROM members WHERE username=? AND password=?';
        $result = $database->prepare($sql);
        $result->bindValue(1, $username);
        $result->bindValue(2, sha1($password));
        $result->execute();
        $row = $result->fetch(PDO::FETCH_ASSOC);
        if ($result->rowCount() >= 1) {
            $query_log = 'INSERT INTO log_tbl SET ip=?,detailes=?,username=?';
            $result = $database->prepare($query_log);
            $result->bindValue(1, $_SERVER['REMOTE_ADDR']);
            $result->bindValue(2, 'کاربر به سایت لاگین کرد');
            $result->bindValue(3, $row['username']);
            $result->execute();
            $_SESSION['name'] = $row['name'];
            header('location:index.php');
            return $result;
        } else {
            header('location:users.php?loginSite=error');
            return false;
        }
    }
}



?>