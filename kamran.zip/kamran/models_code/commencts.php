<?php

function sendComments($title, $content, $info, $idpost)
{

    if (isset($_POST['sendComment'])) {
        global $database;
        $result = $database->prepare('INSERT INTO comments SET title=?,content=?,info=?,idpost=?');
        $result->bindValue(1, $title);
        $result->bindValue(2, $content);
        $result->bindValue(3, $info);
        $result->bindValue(4, $idpost);
        if ($result->execute()) {
            return true;
        } else {
            return false;
        }
    }
}

function listcomment($id)
{
    global $database;
    $result = $database->prepare('SELECT * FROM comments WHERE status=? AND idpost=?');
    $result->bindValue(1, 1);
    $result->bindValue(2, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

function readAnswerComment($id)
{
    global $database;
    $sql = 'SELECT * FROM answercomment WHERE idcomment=?';
    $result = $database->prepare($sql);
    $result->bindValue(1, $id);
    $result->execute();
    if ($result->rowCount() >= 1) {
        $row = $result->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    } else {
        return false;
    }
}

?>