<?php
//var_dump($_SERVER);

echo $_SERVER['PHP_SELF'];