<?php require_once 'common/header.php'; ?>
<?php
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $title = $_GET['search'];
}
$search = search($title);
//var_dump($search);
?>

<br/>
<br/>
<br/>
<br/>
<div class="container">
    <div class="row">
        <div class="panel panel_custome panel-primary m18top">
            <div class="panel-heading panel_heading_custome2">
                نتیجه جستجوی شما :
            </div>
        </div>
        <?php
        if (!empty($search)) {
            foreach ($search as $value2) {
                ?>
                <div class="col-xs-12 col-sm-4 boxPost">
                    <div class="panel panel-default">
                        <div class="panel-heading panel_heading_custome">
                            <img src="<?php echo 'admin/img/post/' . $value2['pic']; ?>" class="img-responsive"/>
                            <span class="i_date"><?php echo convertToShamsi($value2['time']) ?></span>
                        </div>
                        <div class="panel-body panel_body_custome">
                            <p><?php echo $value2['title'] ?></p>
                            <br/>
                            <a href="page.php?<?php echo 'id=' . $value2['id']; ?>"
                               class="btn btn-success pull-left btn_custome buttontwo">ادامه مطلب ...</a>
                        </div>
                    </div>
                </div>
            <?php }
        }
        {
            echo "<div style='margin-top: 18px!important;' class='alert alert-danger'>مطلبی یافت نشد</div>";
        } ?>
    </div>
</div>

<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<?php require_once 'common/footer.php'; ?>
