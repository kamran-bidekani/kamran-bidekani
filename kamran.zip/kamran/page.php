<?php require_once 'common/header.php'; ?>
<?php
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $showPostForEdameMatlab = showPostForEdameMatlab($_GET['id']);
    $times = $showPostForEdameMatlab['time'];
    $time1 = explode(' ', $times);
    $time = $time1[1];
    $date = $time1[0];
    $category = showCategoryById($showPostForEdameMatlab['category']);
} else {
    header('location:' . Address_MySite);
}
?>
<header>
    <div class="text-center">
        <h1><?php echo $showPostForEdameMatlab['title']; ?></h1>
    </div>
</header>
<div class="container m18top">
    <div class="col-sm-12">
        <div class="page_title">
            <a href="#">برای اطلاع از آخرین اخبار و اطلاع از انتشار جدیدترین جلسات آموزشی ما را در تلگرام دنبال
                نمایید.</a>
        </div>
    </div>

    <div class="col-sm-12">
        <div class="col-sm-12" style="background-color: #ffffff;padding: 7px;border-bottom: 1px dashed #797979">

            <div class="page_content_top">
                <div class="col-sm-4">
                    <img src="<?php echo 'admin/img/post/' . $showPostForEdameMatlab['pic']; ?>"
                         class="img-responsive imgtop img-thumbnail">
                </div>
                <div class="col-sm-8 text-center">
                    <p class="p" style="color: #2a6496">توضیحات آموزش : </p><br/>
                    <p class="p">دسته بندی :<?php echo $category['name']; ?> </p><br/>
                    <p class="p">نویسنده <?php echo $showPostForEdameMatlab['writer'] ?></p><br/>
                    <p class="p"><?php echo convertToShamsi($times); ?></p><br/>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-12">
        <div class="col-sm-12" style="background-color: #ffffff">

            <p style="text-align: center;color: #2a6496;margin-top: 22px;font-size: 18px;margin-bottom: 5px">توضیحات
                آموزش : </p>
            <div class="content text-justify" style="padding: 10px;">
                <?php echo $showPostForEdameMatlab['content']; ?>
            </div>


            <?php if (!empty($showPostForEdameMatlab['linkfile'])) { ?>
                <center>
                    <a class="btn btn-danger" style="border-radius: 0!important;"
                       href="<?php echo $showPostForEdameMatlab['linkfile'] ?>" download>دانلود فایل</a>
                </center>
            <?php } ?>


            <div class="panel panel_custome panel-primary m18top">
                <div class="panel-heading panel_heading_custome2">نکته آموزش :</div>
                <div class="panel-body">
                    نکات جالبی در مورد باگ ها وجود داره پیگیرش باشید :)
                </div>
            </div>


        </div>
    </div>

    <div class="col-sm-12" style="margin-top: 18px;">
        <div class="page_title">
            <a href="#" style="font-size: 16px;">
                مطالب مرتبط
            </a>
        </div>
        <div class="mortabet_post">
            <?php
            $postmortabet = postmortabet($category['id'], $_GET['id']);
            if (!empty($postmortabet)) {
                foreach ($postmortabet as $value2) {
                    ?>
                    <div class="col-xs-12 col-sm-4 boxPost">
                        <div class="panel panel-default">
                            <div class="panel-heading panel_heading_custome">
                                <img src="<?php echo 'admin/img/post/' . $value2['pic']; ?>" class="img-responsive"/>
                                <span class="i_date"><?php echo convertToShamsi($value2['time']) ?></span>
                            </div>
                            <div class="panel-body panel_body_custome">
                                <p><?php echo $value2['title'] ?></p><br/>
                                <a href="page.php?<?php echo 'id=' . $value2['id']; ?>"
                                   class="btn btn-success pull-left btn_custome buttontwo">ادامه مطلب
                                    ...</a>
                            </div>
                        </div>
                    </div>
                <?php }
            } else {
                echo "<p class='alert alert-warning'>مطلب مرتبطی وجود ندارد</p>";
            } ?>
        </div>
    </div>


    <div class="col-sm-12" style="margin-top: 18px;">
        <div class="page_title">
            <a href="#" style="font-size: 16px;">
                بخش نظرات سایت
            </a>
        </div>


        <?php
        $listcomment = listcomment($_GET['id']);
        if (!empty($listcomment)) {
            foreach ($listcomment as $value) {
                ?>
                <div class="comments" style="1px solid #efefef!important;">
                    <div class="timeanddate" style="padding: 20px 0;">
                        <span class="namecomment"><?php echo $value['info']; ?> </span>
                        <span class="timecomment">تاریخ بیست ابان ماه ساعت چهار عصر</span>
                    </div>
                    <div class="soal">
                        <p><?php echo $value['content']; ?></p>
                    </div>
                    <?php
//                    echo $value['id'];
//                    die()
                    $listAnswerComment = readAnswerComment($value['id']);
                    if(!empty($listAnswerComment)){
                    foreach ($listAnswerComment as $val) {
                        ?>
                        <div class="answerComment">
                            <p class="admin">مدیر سایت گفت : </p>

                            <p><?php echo $val['content']; ?></p>

                        </div>
                    <?php }} ?>
                </div>
            <?php }
        } else {
            echo '<p style="margin-top: 8px;" class="alert alert-warning">نظری وجود ندارد</p>';
        } ?>

        <?php if (isset($_SESSION['name'])) { ?>
            <center>
                <?php
                sendComments($showPostForEdameMatlab['title'], @$_POST['commentContent'], $_SESSION['name'], $_GET['id']);
                ?>
                <!-- Trigger the modal with a button -->
                <button style="border-radius: 0!important;" type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#myModal">ارسال نظر در سایت
                </button>

                <!-- Modal -->
                <div id="myModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">بخش ارسال نظر در سایت</h4>
                            </div>
                            <div class="modal-body">
                                <form method="post">
                                    <p>
                                    <div class="form-group">
                                <textarea class="form-control" name="commentContent" rows="5" id="comment"
                                          placeholder="نظر خود را در این قسمت وارد نمایید"></textarea>
                                    </div>

                                    <button type="submit" name="sendComment" class="btn btn-block btn-primary"
                                            style="border-radius: 0!important;">ارسال
                                    </button>
                                    </p>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">بستن</button>
                            </div>
                        </div>

                    </div>
                </div>
            </center>
        <?php } else {
            echo "<p class='alert alert-warning'>برای ارسال نظر در سایت باید به سایت ورود کنید </p>";
        } ?>
    </div>
</div>
</div>
<br/>
<br/>
<?php require_once 'common/footer.php'; ?>
